# GPT-5 Chat — FastAPI + HTML

Real-time streaming chat UI powered by GPT-5 via the OpenAI API.

## Features
- **SSE streaming** — tokens appear as they're generated
- **Conversation memory** — full history sent each turn
- **Markdown rendering** — code blocks, lists, bold, etc.
- **New chat** — one click to reset the session
- **Suggestion chips** — quick-start prompts on the welcome screen

## Setup

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Set your API key
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY

# 3. Run
uvicorn main:app --reload --port 8000
```

Open **http://localhost:8000**

## Configuration

| Variable | Default | Description |
|---|---|---|
| `OPENAI_API_KEY` | — | Your OpenAI API key (required) |
| `MODEL` | `gpt-5` | Model name |
| `MAX_TOKENS` | `4096` | Max tokens per response |
| `TEMPERATURE` | `0.7` | Response creativity (0–2) |
| `SYSTEM_PROMPT` | see .env.example | System instruction |

## API Endpoints

| Method | Path | Description |
|---|---|---|
| `GET` | `/` | Chat UI |
| `POST` | `/chat` | Non-streaming (full reply) |
| `POST` | `/chat/stream` | SSE streaming |
| `POST` | `/chat/reset` | Clear session history |

## Project Structure

```
gpt5-chat/
├── main.py           # FastAPI app + endpoints
├── config.py         # Settings (pydantic-settings)
├── requirements.txt
├── .env.example
└── static/
    └── index.html    # Chat UI (self-contained)
```
