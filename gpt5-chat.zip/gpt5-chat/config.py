from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    OPENAI_API_KEY: str
    MODEL: str = "gpt-5"
    MAX_TOKENS: int = 4096
    TEMPERATURE: float = 0.7
    SYSTEM_PROMPT: str = (
        "You are a helpful, thoughtful AI assistant. "
        "Be concise when brevity serves the user; be detailed when depth is needed."
    )


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]


settings = get_settings()
