"""
GPT-5 Chat — FastAPI backend

Endpoints:
  GET  /              → serves index.html
  POST /chat          → non-streaming chat (returns full message)
  POST /chat/stream   → SSE streaming chat
  POST /chat/reset    → clear conversation history (server-side session)
"""

import json
import logging
from typing import AsyncIterator

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from openai import AsyncOpenAI

from config import settings

logging.basicConfig(level="INFO", format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger(__name__)

app = FastAPI(title="GPT-5 Chat", version="1.0.0", docs_url="/api/docs")
app.mount("/static", StaticFiles(directory="static"), name="static")

client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

# ── In-memory conversation store (keyed by session_id) ────────────────────────
# For production replace with Redis or a database.
conversations: dict[str, list[dict]] = {}


# ── Schemas ───────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str
    session_id: str = "default"


class ResetRequest(BaseModel):
    session_id: str = "default"


# ── Helpers ───────────────────────────────────────────────────────────────────

def get_history(session_id: str) -> list[dict]:
    if session_id not in conversations:
        conversations[session_id] = [
            {"role": "system", "content": settings.SYSTEM_PROMPT}
        ]
    return conversations[session_id]


def append_user(session_id: str, content: str):
    get_history(session_id).append({"role": "user", "content": content})


def append_assistant(session_id: str, content: str):
    get_history(session_id).append({"role": "assistant", "content": content})


# ── Routes ─────────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def index():
    with open("static/index.html", encoding="utf-8") as f:
        return f.read()


@app.post("/chat")
async def chat(req: ChatRequest):
    """Non-streaming: returns full assistant reply."""
    append_user(req.session_id, req.message)
    try:
        resp = await client.chat.completions.create(
            model=settings.MODEL,
            messages=get_history(req.session_id),
            max_tokens=settings.MAX_TOKENS,
            temperature=settings.TEMPERATURE,
        )
        reply = resp.choices[0].message.content or ""
        append_assistant(req.session_id, reply)
        return {
            "reply": reply,
            "tokens_used": resp.usage.total_tokens if resp.usage else None,
        }
    except Exception as exc:
        logger.error("OpenAI error: %s", exc)
        raise HTTPException(status_code=502, detail=str(exc))


async def _stream_tokens(session_id: str, message: str) -> AsyncIterator[str]:
    """Yield SSE data chunks from OpenAI streaming response."""
    append_user(session_id, message)
    full_reply: list[str] = []

    try:
        stream = await client.chat.completions.create(
            model=settings.MODEL,
            messages=get_history(session_id),
            max_tokens=settings.MAX_TOKENS,
            temperature=settings.TEMPERATURE,
            stream=True,
        )

        async for chunk in stream:
            delta = chunk.choices[0].delta.content if chunk.choices else None
            if delta:
                full_reply.append(delta)
                # SSE format: data: <json>\n\n
                payload = json.dumps({"token": delta})
                yield f"data: {payload}\n\n"

        # Persist completed reply to history
        append_assistant(session_id, "".join(full_reply))
        yield "data: [DONE]\n\n"

    except Exception as exc:
        logger.error("Streaming error: %s", exc)
        error_payload = json.dumps({"error": str(exc)})
        yield f"data: {error_payload}\n\n"


@app.post("/chat/stream")
async def chat_stream(req: ChatRequest):
    """SSE streaming endpoint — tokens arrive in real time."""
    return StreamingResponse(
        _stream_tokens(req.session_id, req.message),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",  # Disable nginx buffering
        },
    )


@app.post("/chat/reset")
async def reset(req: ResetRequest):
    """Clear conversation history for a session."""
    conversations.pop(req.session_id, None)
    logger.info("Session %s reset", req.session_id)
    return {"status": "ok", "session_id": req.session_id}
