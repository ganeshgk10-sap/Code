"""SQLite persistence for analysis history. Single local file, zero setup."""

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "history.db"


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with _connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS analyses (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT    NOT NULL,
                filename   TEXT,
                code       TEXT    NOT NULL,
                result     TEXT    NOT NULL
            )
            """
        )


def save_analysis(code: str, filename: str | None, result: dict) -> int:
    created_at = datetime.now(timezone.utc).isoformat()
    with _connect() as conn:
        cur = conn.execute(
            "INSERT INTO analyses (created_at, filename, code, result) VALUES (?, ?, ?, ?)",
            (created_at, filename, code, json.dumps(result)),
        )
        return cur.lastrowid


def list_analyses(limit: int = 50) -> list[dict]:
    with _connect() as conn:
        rows = conn.execute(
            """
            SELECT id, created_at, filename, result
            FROM analyses
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()

    items = []
    for row in rows:
        result = json.loads(row["result"])
        items.append(
            {
                "id": row["id"],
                "created_at": row["created_at"],
                "filename": row["filename"],
                "summary": result.get("summary", ""),
                "overall_severity": result.get("overall_severity", "Info"),
                "finding_count": len(result.get("findings", [])),
            }
        )
    return items


def get_analysis(analysis_id: int) -> dict | None:
    with _connect() as conn:
        row = conn.execute(
            "SELECT id, created_at, filename, code, result FROM analyses WHERE id = ?",
            (analysis_id,),
        ).fetchone()

    if row is None:
        return None
    return {
        "id": row["id"],
        "created_at": row["created_at"],
        "filename": row["filename"],
        "code": row["code"],
        "result": json.loads(row["result"]),
    }
