"""Provider-agnostic dispatcher.

Picks the LLM backend based on the LLM_PROVIDER env var, or auto-detects from
whichever API key is configured. Both backends expose the same
analyze_code(code, filename) -> dict interface.
"""

import os


def _is_real_key(env_name: str) -> bool:
    """True if the env var is set to something that looks like a real key."""
    value = (os.getenv(env_name) or "").strip()
    return bool(value) and "your-key" not in value.lower()


def active_provider() -> str:
    """Resolve the provider name: 'anthropic' or 'openai'."""
    choice = (os.getenv("LLM_PROVIDER") or "").strip().lower()
    if choice in ("anthropic", "claude"):
        return "anthropic"
    if choice in ("openai", "gpt"):
        return "openai"

    # No explicit choice — auto-detect from configured keys (Claude preferred).
    if _is_real_key("ANTHROPIC_API_KEY"):
        return "anthropic"
    if _is_real_key("OPENAI_API_KEY"):
        return "openai"
    return "anthropic"


def active_model() -> str:
    """The model name for the active provider (for display/logging)."""
    if active_provider() == "anthropic":
        return os.getenv("ANTHROPIC_MODEL", "claude-opus-4-8")
    return os.getenv("OPENAI_MODEL", "gpt-4.1")


def analyze_code(code: str, filename: str | None = None) -> dict:
    if active_provider() == "anthropic":
        from . import anthropic_client
        return anthropic_client.analyze_code(code, filename)
    from . import openai_client
    return openai_client.analyze_code(code, filename)
