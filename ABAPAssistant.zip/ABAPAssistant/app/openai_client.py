"""Thin wrapper around the OpenAI client that returns a validated review dict."""

import json
import os

from openai import OpenAI

from .prompts import SYSTEM_PROMPT, build_user_message
from .schema import REVIEW_JSON_SCHEMA

_client: OpenAI | None = None


def _get_client() -> OpenAI:
    global _client
    if _client is None:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError(
                "OPENAI_API_KEY is not set. Copy .env.example to .env and add your key."
            )
        _client = OpenAI(api_key=api_key)
    return _client


def analyze_code(code: str, filename: str | None = None) -> dict:
    """Send code to the model and return the parsed, schema-conforming review."""
    model = os.getenv("OPENAI_MODEL", "gpt-4.1")
    client = _get_client()

    completion = client.chat.completions.create(
        model=model,
        temperature=0.2,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": build_user_message(code, filename)},
        ],
        response_format={"type": "json_schema", "json_schema": REVIEW_JSON_SCHEMA},
    )

    content = completion.choices[0].message.content or "{}"
    return json.loads(content)
