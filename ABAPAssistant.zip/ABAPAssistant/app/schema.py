"""JSON schema for the LLM's structured review output.

We use OpenAI Structured Outputs (strict mode) so the model is *guaranteed*
to return this exact shape. In strict mode every property must be listed in
`required` and `additionalProperties` must be false.
"""

CATEGORIES = ["Security", "Best Practices", "Efficiency", "Scalability"]
SEVERITIES = ["Critical", "High", "Medium", "Low", "Info"]

REVIEW_JSON_SCHEMA = {
    "name": "abap_review",
    "strict": True,
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "summary": {
                "type": "string",
                "description": "A concise overall assessment of the submitted code.",
            },
            "is_rap_abap": {
                "type": "string",
                "description": (
                    "A short sanity note on whether the input looks like RAP ABAP "
                    "(RESTful Application Programming model). If it is plain ABAP or "
                    "not ABAP at all, say so plainly."
                ),
            },
            "overall_severity": {
                "type": "string",
                "enum": SEVERITIES,
                "description": "The single most severe issue level found in the code.",
            },
            "findings": {
                "type": "array",
                "description": "Individual review findings. Empty array if none.",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "category": {"type": "string", "enum": CATEGORIES},
                        "title": {"type": "string"},
                        "severity": {"type": "string", "enum": SEVERITIES},
                        "line_reference": {
                            "type": "string",
                            "description": "Line(s) the finding refers to, e.g. 'lines 12-15'. Use 'n/a' if not applicable.",
                        },
                        "issue": {
                            "type": "string",
                            "description": "What is wrong and why it is a problem.",
                        },
                        "recommendation": {
                            "type": "string",
                            "description": "Concrete guidance on how to fix it.",
                        },
                        "code_suggestion": {
                            "type": "string",
                            "description": "An improved ABAP snippet if helpful, else an empty string.",
                        },
                        "why_it_matters": {
                            "type": "string",
                            "description": "Plain-language educational explanation for someone new to RAP ABAP.",
                        },
                    },
                    "required": [
                        "category",
                        "title",
                        "severity",
                        "line_reference",
                        "issue",
                        "recommendation",
                        "code_suggestion",
                        "why_it_matters",
                    ],
                },
            },
            "education": {
                "type": "object",
                "additionalProperties": False,
                "description": "Teaching section so newcomers understand the code.",
                "properties": {
                    "what_this_code_does": {
                        "type": "string",
                        "description": "Plain-language explanation of what the submitted code does.",
                    },
                    "rap_concepts": {
                        "type": "array",
                        "description": "Key RAP/ABAP concepts present in the code, explained simply.",
                        "items": {
                            "type": "object",
                            "additionalProperties": False,
                            "properties": {
                                "concept": {"type": "string"},
                                "explanation": {"type": "string"},
                            },
                            "required": ["concept", "explanation"],
                        },
                    },
                    "learning_notes": {
                        "type": "string",
                        "description": "Extra tips or pointers for someone learning RAP ABAP.",
                    },
                },
                "required": ["what_this_code_does", "rap_concepts", "learning_notes"],
            },
        },
        "required": [
            "summary",
            "is_rap_abap",
            "overall_severity",
            "findings",
            "education",
        ],
    },
}
