"""Claude (Anthropic) backend that returns a validated review dict.

Uses the Messages API with structured outputs (output_config.format) so the
model returns JSON matching our schema, plus adaptive thinking for the review
reasoning. Mirrors the interface of openai_client.analyze_code.
"""

import json
import os

import anthropic

from .prompts import SYSTEM_PROMPT, build_user_message
from .schema import REVIEW_JSON_SCHEMA

_client: anthropic.Anthropic | None = None


def _get_client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise RuntimeError(
                "ANTHROPIC_API_KEY is not set. Copy .env.example to .env and add your key."
            )
        _client = anthropic.Anthropic(api_key=api_key)
    return _client


def analyze_code(code: str, filename: str | None = None) -> dict:
    """Send code to Claude and return the parsed, schema-conforming review."""
    model = os.getenv("ANTHROPIC_MODEL", "claude-opus-4-8")
    client = _get_client()

    request_kwargs = {
        "model": model,
        "max_tokens": 16000,
        "system": SYSTEM_PROMPT,
        "messages": [{"role": "user", "content": build_user_message(code, filename)}],
        "output_config": {
            "format": {"type": "json_schema", "schema": REVIEW_JSON_SCHEMA["schema"]}
        },
    }
    # Adaptive thinking sharpens the review, but it's only on the larger models
    # (Opus/Sonnet/Fable). Haiku doesn't support it, so omit it there.
    if "haiku" not in model.lower():
        request_kwargs["thinking"] = {"type": "adaptive"}

    message = client.messages.create(**request_kwargs)

    if message.stop_reason == "refusal":
        raise RuntimeError("Claude declined to analyze this input (safety refusal).")

    # With structured outputs the answer is a text block containing the JSON.
    text = next((b.text for b in message.content if b.type == "text"), None)
    if not text:
        raise RuntimeError("Claude returned no text content to parse.")
    return json.loads(text)
