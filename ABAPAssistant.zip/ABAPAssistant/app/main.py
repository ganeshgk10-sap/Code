"""FastAPI app: serves the UI and the analyze/history endpoints."""

import os
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import db
from .llm import active_model, active_provider, analyze_code

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"

MAX_CODE_CHARS = 60_000

app = FastAPI(title="RAP ABAP Review & Learn Assistant")


@app.on_event("startup")
def _startup() -> None:
    db.init_db()


class AnalyzeRequest(BaseModel):
    code: str = Field(..., min_length=1)
    filename: str | None = None


@app.get("/")
def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/config")
def config() -> dict:
    """Tell the UI which backend is active (for the loading label)."""
    return {"provider": active_provider(), "model": active_model()}


@app.post("/analyze")
def analyze(req: AnalyzeRequest) -> dict:
    code = req.code.strip()
    if not code:
        raise HTTPException(status_code=400, detail="No code provided.")
    if len(code) > MAX_CODE_CHARS:
        raise HTTPException(
            status_code=413,
            detail=f"Code is too large (>{MAX_CODE_CHARS} chars). Trim it and retry.",
        )

    try:
        result = analyze_code(code, req.filename)
    except RuntimeError as exc:  # missing API key, etc.
        raise HTTPException(status_code=500, detail=str(exc))
    except Exception as exc:  # network / model errors
        raise HTTPException(status_code=502, detail=f"Analysis failed: {exc}")

    analysis_id = db.save_analysis(code, req.filename, result)
    return {"id": analysis_id, "result": result}


@app.get("/history")
def history() -> dict:
    return {"items": db.list_analyses()}


@app.get("/history/{analysis_id}")
def history_item(analysis_id: int) -> dict:
    item = db.get_analysis(analysis_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Analysis not found.")
    return item


# Static assets (css/js) served under /static
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
