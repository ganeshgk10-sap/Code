"use strict";

const $ = (id) => document.getElementById(id);

const codeInput = $("codeInput");
const fileInput = $("fileInput");
const analyzeBtn = $("analyzeBtn");
const clearBtn = $("clearBtn");
const charCount = $("charCount");
const output = $("output");
const historyBtn = $("historyBtn");
const historyDrawer = $("historyDrawer");
const closeHistory = $("closeHistory");
const historyList = $("historyList");

let currentFilename = null;
let activeModelLabel = "the model";

// Fetch which backend is active so the loading label is accurate.
fetch("/config")
  .then((r) => r.json())
  .then((c) => { if (c && c.model) activeModelLabel = c.model; })
  .catch(() => {});

// ---- helpers -------------------------------------------------------------

function esc(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

// CSS classes can't contain spaces; map category -> class suffix.
const CAT_CLASS = {
  Security: "Security",
  "Best Practices": "Best",
  Efficiency: "Efficiency",
  Scalability: "Scalability",
};

function updateCharCount() {
  charCount.textContent = `${codeInput.value.length.toLocaleString()} chars`;
}

// ---- rendering -----------------------------------------------------------

function renderFinding(f) {
  const catClass = CAT_CLASS[f.category] || "Best";
  const codeBlock = f.code_suggestion && f.code_suggestion.trim()
    ? `<p class="label">Suggested fix</p><pre>${esc(f.code_suggestion)}</pre>`
    : "";
  return `
    <div class="finding cat-${catClass}">
      <div class="finding-head">
        <span class="sev-pill sev-${esc(f.severity)}">${esc(f.severity)}</span>
        <span class="cat-pill">${esc(f.category)}</span>
        <span class="title">${esc(f.title)}</span>
        <span class="line-ref">${esc(f.line_reference)}</span>
      </div>
      <p><span class="label">Issue</span><br>${esc(f.issue)}</p>
      <p><span class="label">Recommendation</span><br>${esc(f.recommendation)}</p>
      ${codeBlock}
      <div class="why"><span class="label">Why it matters</span><br>${esc(f.why_it_matters)}</div>
    </div>`;
}

function renderResult(result) {
  const findings = result.findings || [];

  const findingsHtml = findings.length
    ? findings.map(renderFinding).join("")
    : `<div class="no-findings">✓ No issues found across the four review categories.</div>`;

  const edu = result.education || {};
  const concepts = (edu.rap_concepts || [])
    .map((c) => `<div class="concept"><b>${esc(c.concept)}</b> — ${esc(c.explanation)}</div>`)
    .join("");

  output.innerHTML = `
    <div class="summary-block">
      <h3>Summary
        <span class="sev-pill sev-${esc(result.overall_severity)}" style="margin-left:8px">${esc(result.overall_severity)}</span>
      </h3>
      <div>${esc(result.summary)}</div>
      <div class="rap-note">${esc(result.is_rap_abap)}</div>
    </div>

    <div class="section-title">Findings (${findings.length})</div>
    ${findingsHtml}

    <div class="section-title">Learn this code</div>
    <div class="edu-block">
      <h4>What this code does</h4>
      <div>${esc(edu.what_this_code_does)}</div>
      ${concepts ? `<h4 style="margin-top:12px">Key RAP concepts</h4>${concepts}` : ""}
      ${edu.learning_notes ? `<h4 style="margin-top:12px">Learning notes</h4><div>${esc(edu.learning_notes)}</div>` : ""}
    </div>`;
}

function showLoading() {
  output.innerHTML = `<div class="spinner"></div><div class="loading-text">Analyzing with ${esc(activeModelLabel)}…</div>`;
}

function showError(msg) {
  output.innerHTML = `<div class="error-box"><b>Something went wrong.</b><br>${esc(msg)}</div>`;
}

// ---- actions -------------------------------------------------------------

async function analyze() {
  const code = codeInput.value.trim();
  if (!code) {
    showError("Please paste or upload some ABAP code first.");
    return;
  }
  analyzeBtn.disabled = true;
  showLoading();
  try {
    const res = await fetch("/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, filename: currentFilename }),
    });
    const data = await res.json();
    if (!res.ok) {
      showError(data.detail || `Request failed (${res.status})`);
      return;
    }
    renderResult(data.result);
  } catch (err) {
    showError(err.message || "Network error.");
  } finally {
    analyzeBtn.disabled = false;
  }
}

function loadFile(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    codeInput.value = e.target.result;
    currentFilename = file.name;
    updateCharCount();
  };
  reader.readAsText(file);
}

async function openHistory() {
  historyDrawer.classList.remove("hidden");
  historyList.innerHTML = `<li class="muted" style="padding:8px">Loading…</li>`;
  try {
    const res = await fetch("/history");
    const data = await res.json();
    const items = data.items || [];
    if (!items.length) {
      historyList.innerHTML = `<li class="muted" style="padding:8px">No analyses yet.</li>`;
      return;
    }
    historyList.innerHTML = items
      .map(
        (it) => `
        <li class="history-item" data-id="${it.id}">
          <div>${esc(it.summary).slice(0, 90) || "(no summary)"}</div>
          <div class="meta">
            <span class="sev-pill sev-${esc(it.overall_severity)}">${esc(it.overall_severity)}</span>
            <span>${esc(it.filename || "pasted")} · ${it.finding_count} findings</span>
          </div>
        </li>`
      )
      .join("");
  } catch (err) {
    historyList.innerHTML = `<li class="error-box">Failed to load history.</li>`;
  }
}

async function loadHistoryItem(id) {
  historyDrawer.classList.add("hidden");
  showLoading();
  try {
    const res = await fetch(`/history/${id}`);
    const data = await res.json();
    if (!res.ok) { showError(data.detail || "Not found."); return; }
    codeInput.value = data.code;
    currentFilename = data.filename;
    updateCharCount();
    renderResult(data.result);
  } catch (err) {
    showError(err.message);
  }
}

// ---- events --------------------------------------------------------------

analyzeBtn.addEventListener("click", analyze);
clearBtn.addEventListener("click", () => {
  codeInput.value = "";
  currentFilename = null;
  updateCharCount();
  output.innerHTML = `<div class="placeholder">Your structured review will appear here.</div>`;
});
codeInput.addEventListener("input", () => {
  currentFilename = null; // typing overrides uploaded filename
  updateCharCount();
});
fileInput.addEventListener("change", (e) => loadFile(e.target.files[0]));
historyBtn.addEventListener("click", openHistory);
closeHistory.addEventListener("click", () => historyDrawer.classList.add("hidden"));
historyList.addEventListener("click", (e) => {
  const li = e.target.closest(".history-item");
  if (li) loadHistoryItem(li.dataset.id);
});

// Ctrl/Cmd + Enter to analyze
codeInput.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") analyze();
});

updateCharCount();
