# RAP ABAP Review & Learn Assistant

A simple, local, login-free web app that reviews **RAP ABAP** code and teaches
newcomers at the same time. Paste or upload ABAP, click **Analyze**, and get a
structured report across **Security, Best Practices, Efficiency, and Scalability**,
plus a plain-language explanation of what the code does.

- **Backend:** Python + FastAPI
- **LLM:** pluggable — **Claude** (`claude-opus-4-8`, default) or **OpenAI** (`gpt-4.1`),
  both using structured outputs for a guaranteed JSON shape
- **Frontend:** lightweight HTML/CSS/vanilla JS (no framework)
- **Storage:** SQLite (`data/history.db`) — every analysis is saved and browsable

> Note: This is an LLM-based advisory review. It does **not** connect to an SAP
> system and does **not** run a real ATC check.

## Setup

This project uses a dedicated virtual environment at
`~/SysApps/py-envirnoments/abap-assistant`.

```bash
# 1. Activate the venv
source ~/SysApps/py-envirnoments/abap-assistant/bin/activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Configure your API key
cp .env.example .env
#   Claude (default): set ANTHROPIC_API_KEY=sk-ant-...
#   OpenAI instead:   set LLM_PROVIDER=openai and OPENAI_API_KEY=sk-...

# 4. Run
uvicorn app.main:app --reload --port 8000
```

### Choosing the backend

`LLM_PROVIDER` selects the backend: `anthropic` (Claude, default) or `openai`.
If left blank, the app auto-detects from whichever API key is set (Claude preferred).
`GET /config` reports the active provider and model.

Open http://127.0.0.1:8000 in your browser.

## Project layout

```
ABAPAssistant/
├── app/
│   ├── main.py             # FastAPI routes (/, /config, /analyze, /history)
│   ├── llm.py              # provider dispatcher (anthropic | openai)
│   ├── anthropic_client.py # Claude call + structured output
│   ├── openai_client.py    # OpenAI call + structured output
│   ├── prompts.py          # System prompt
│   ├── schema.py           # JSON schema for the review
│   └── db.py               # SQLite history
├── static/               # index.html, style.css, app.js
├── data/                 # history.db (auto-created, git-ignored)
├── requirements.txt
├── .env.example
└── README.md
```

## Configuration (.env)

| Variable | Default | Purpose |
|---|---|---|
| `LLM_PROVIDER` | `anthropic` | `anthropic` (Claude) or `openai`. Blank = auto-detect. |
| `ANTHROPIC_API_KEY` | — | Required when using Claude. |
| `ANTHROPIC_MODEL` | `claude-opus-4-8` | Claude model to use. |
| `OPENAI_API_KEY` | — | Required when using OpenAI. |
| `OPENAI_MODEL` | `gpt-4.1` | OpenAI model to use. |
| `APP_HOST` | `127.0.0.1` | Host (informational). |
| `APP_PORT` | `8000` | Port (informational). |

## Out of scope (v1)

Auth/login · real SAP/ATC connection · multi-file projects · multi-user · cloud deploy.
