# RAP (Restful Application Programming Model) - Complete Code Examples

## Overview
This directory contains comprehensive examples of RAP implementation following SAP BTP and S/4HANA Cloud best practices. 

## Project Structure

```
RAP_Code_Examples/
├── z_travel_entity.cds          # Data Model (CDS Entities)
├── z_travel_behavior.cds        # Behavior Definition
├── z_travel_behavior. abap       # Behavior Implementation
├── z_travel_projection.cds      # OData Service Projection
├── z_travel_service.cds         # Service Definition
└── README.md                     # This file
```

## Key RAP Concepts Demonstrated

### 1. **Entity Definition (CDS)**
- Root entities with UUID primary keys
- Composition relationships (1:N)
- Enums for status fields
- Managed fields (created_at, created_by, etc.)

### 2. **Behavior Definition**
- CRUD Operations (Create, Update, Delete)
- Draft mode operations
- Custom Actions (Accept, Reject, ResetStatus)
- Validations
- Side Effects
- Field Control (readonly, mandatory)

### 3. **Behavior Implementation (ABAP)**
- Instance features (dynamic UI control)
- Authorization checks
- Custom action implementations
- Data validations with error messages
- CQN (Core Query Notation) for data operations

### 4. **Service Projection**
- OData service exposure
- Type definitions
- Composition handling
- Field exclusions

---

## Code Examples Breakdown

### Example 1: Entity with Composition

**File:** `z_travel_entity. cds`

```cds
entity Travel : cuid, managed {
    travel_id      : UUID;
    travel_code    : String(10) unique;
    status         : String(1) enum {
        Open = 'O';
        Accepted = 'A';
        Rejected = 'X';
    };
    bookings       : array of Booking on bookings. travel = $self;
};
```

**Key Points:**
- `cuid` adds UUID and system timestamps
- `managed` adds created_by, modified_by, etc.
- Composition via `array of Booking`
- Enum for type safety

---

### Example 2: Behavior Definition with Actions

**File:** `z_travel_behavior.cds`

```cds
define behavior for Travel alias Travel {
  create;
  update;
  delete;
  
  action Accept result [1];
  action Reject result [1];
  
  validation ValidateTravelData on save;
  
  field ( readonly ) travel_id, created_at, created_by;
  field ( mandatory ) agency_id, customer_id;
}
```

**Key Points:**
- Standard CRUD operations
- Custom actions with single result
- Validations on save
- Field-level control

---

### Example 3: Action Implementation in ABAP

**File:** `z_travel_behavior.abap`

```abap
METHOD accept.
  MODIFY ENTITIES OF travel IN LOCAL MODE
    ENTITY travel
      UPDATE SET ( status = 'A' )
      WHERE travel_id IN ( SELECT travel_id FROM @keys ). 

  READ ENTITIES OF travel IN LOCAL MODE
    ENTITY travel FROM CORRESPONDING #( keys )
    RESULT DATA(travels). 

  result = travels. 
ENDMETHOD.
```

**Key Points:**
- Use MODIFY ENTITIES for write operations
- Use READ ENTITIES for read operations
- Dynamic WHERE clauses with keys
- Return modified data to client

---

### Example 4: Validation Implementation

**File:** `z_travel_behavior.abap`

```abap
METHOD validate_dates.
  READ ENTITIES OF travel IN LOCAL MODE
    ENTITY travel FROM CORRESPONDING #( keys )
    FIELDS ( begin_date end_date )
    RESULT DATA(travels).

  LOOP AT travels ASSIGNING FIELD-SYMBOL(<travel>).
    IF <travel>-end_date < <travel>-begin_date. 
      APPEND VALUE #(
        %key = <travel>-%key
        %msg = new_message_with_text(
          severity = if_abap_behv=>severity-error
          text = 'End date must be after begin date'
        )
      ) TO reported-travel.
    ENDIF.
  ENDLOOP.
ENDMETHOD.
```

**Key Points:**
- Read relevant fields only
- Loop through results
- Append to reported structure with messages
- Multiple validations possible

---

### Example 5: Features for Dynamic UI Control

**File:** `z_travel_behavior.abap`

```abap
METHOD get_instance_features.
  READ ENTITIES OF travel IN LOCAL MODE
    ENTITY travel FROM CORRESPONDING #( keys )
    FIELDS ( status ) RESULT DATA(travels).

  LOOP AT travels ASSIGNING FIELD-SYMBOL(<travel>).
    APPEND VALUE #(
      %key = <travel>-%key
      %features-%action-accept = COND #( 
        WHEN <travel>-status = 'O' THEN abap_true 
        ELSE abap_false 
      )
      %features-%update = COND #( 
        WHEN <travel>-status = 'O' THEN abap_true 
        ELSE abap_false 
      )
    ) TO result.
  ENDLOOP. 
ENDMETHOD.
```

**Key Points:**
- Control action availability based on data
- Control create/update/delete based on conditions
- Dynamic UI behavior

---

## REST API Endpoints (OData v4)

### Read Operations

**Get all travels:**
```
GET /service/Travel
```

**Get single travel with bookings:**
```
GET /service/Travel(guid'12345678-1234-1234-1234-123456789012')? $expand=bookings
```

**Filter by status:**
```
GET /service/Travel?$filter=status eq 'O'
```

### Create Operation

**Create new travel:**
```
POST /service/Travel
Content-Type: application/json

{
  "travel_code": "TR001",
  "agency_id": "001",
  "customer_id": "C00001",
  "begin_date": "2025-01-15",
  "end_date": "2025-01-20",
  "total_price": "5000.00",
  "currency_code": "USD",
  "description": "Business trip to NYC"
}
```

### Update Operation

**Update travel:**
```
PATCH /service/Travel(guid'.. .')/
Content-Type: application/json

{
  "description": "Updated description",
  "total_price": "5500.00"
}
```

### Custom Action

**Accept travel request:**
```
POST /service/Travel(guid'...')/TravelService.Accept
```

**Response:**
```json
{
  "travel_id": "12345678-1234-1234-1234-123456789012",
  "travel_code": "TR001",
  "status": "A",
  "... ": "..."
}
```

---

## Implementation Steps

### Step 1: Create Data Model
- Define entities in `z_travel_entity.cds`
- Add relationships and compositions
- Use appropriate data types and validations

### Step 2: Define Behavior
- Create `z_travel_behavior.cds`
- Define CRUD operations
- Add custom actions and validations
- Set field controls

### Step 3: Implement Behavior
- Create `z_travel_behavior.abap`
- Implement handlers for each method
- Add business logic and validations
- Handle error scenarios

### Step 4: Create Service Projection
- Define OData service in `z_travel_projection.cds`
- Specify exposed fields
- Handle nested structures

### Step 5: Activate and Test
- Activate all CDS definitions
- Test via OData endpoints
- Use REST client (Postman, Insomnia, etc.)

---

## Best Practices

### 1. **Entity Design**
- Always use UUID for primary keys
- Use `cuid` mixin for audit fields
- Define clear relationships
- Use enums for fixed value sets

### 2. **Validation**
- Validate at field level (format)
- Validate at entity level (logic)
- Provide clear error messages
- Use appropriate severity levels

### 3. **Performance**
- Read only required fields
- Use efficient WHERE clauses
- Limit nested reads
- Consider pagination

### 4. **Security**
- Always check authorization
- Validate user input
- Use role-based access control
- Implement field-level security

### 5.  **Error Handling**
- Catch and log exceptions
- Return meaningful error messages
- Rollback failed transactions
- Provide recovery options

---

## Common Patterns

### Pattern 1: Master-Detail Composition
```cds
entity Master : cuid, managed {
  details: array of Detail on details.master = $self;
};

entity Detail : cuid, managed {
  master: Association to Master;
};
```

### Pattern 2: Enum-based Status
```cds
status: String(1) enum {
  Pending = 'P';
  Approved = 'A';
  Rejected = 'X';
} default 'P';
```

### Pattern 3: Custom Action with Parameters
```abap
METHOD custom_action.
  LOOP AT keys INTO DATA(key).
    " Get additional data if needed
    READ ENTITIES OF entity IN LOCAL MODE
      ENTITY entity FROM @( VALUE #( ( %key = key ) ) )
      RESULT DATA(items).
    
    " Perform business logic
    
    " Update entity
    MODIFY ENTITIES OF entity IN LOCAL MODE
      ENTITY entity UPDATE SET ( status = 'X' ) 
      WHERE id = key.
  ENDLOOP. 
ENDMETHOD.
```

---

## Testing

### Unit Testing
```abap
CLASS lhc_travel_test DEFINITION FOR TESTING.
  PRIVATE SECTION.
    METHODS:
      test_accept ACTION,
      test_validation ACTION,
      test_reject ACTION. 
ENDCLASS.

CLASS lhc_travel_test IMPLEMENTATION.
  METHOD test_accept.
    " Test implementation
  ENDMETHOD. 
ENDCLASS.
```

### Integration Testing
- Use CAP test framework
- Mock external calls
- Test full flow from UI to DB

---

## Resources

- [SAP CAP Documentation](https://cap.cloud.sap/docs/)
- [RAP Best Practices](https://github.com/SAP-samples/cloud-cap-samples)
- [ABAP Cloud Syntax](https://help.sap.com/docs/ABAP_CLOUD)
- [OData v4 Specification](https://www.odata.org/)

---

## Author Notes

These examples follow SAP's recommended architecture patterns and are optimized for:
- Cloud deployment (SAP BTP)
- Full-stack ABAP development
- Enterprise applications
- Multi-tenant environments

Last Updated: December 2025