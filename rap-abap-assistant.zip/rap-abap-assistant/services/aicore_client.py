"""
SAP BTP AI Core – Generative AI Hub client.

Auth flow:
  1. POST client_credentials to AICORE_AUTH_URL/oauth/token  → Bearer token (cached)
  2. POST chat/completions to
       AICORE_BASE_URL/v2/inference/deployments/{DEPLOYMENT_ID}/chat/completions
     Headers: Authorization, AI-Resource-Group, Content-Type
"""

import time
import httpx
import logging
from typing import Any

from config import settings

logger = logging.getLogger(__name__)


class TokenCache:
    """Simple in-process OAuth2 token cache with 60-second safety margin."""

    def __init__(self):
        self._token: str | None = None
        self._expires_at: float = 0.0

    def is_valid(self) -> bool:
        return self._token is not None and time.time() < self._expires_at

    def set(self, token: str, expires_in: int):
        self._token = token
        self._expires_at = time.time() + expires_in - 60  # 60-s safety margin

    @property
    def token(self) -> str | None:
        return self._token


_token_cache = TokenCache()


async def _fetch_token(client: httpx.AsyncClient) -> str:
    """Fetch a new OAuth2 token from SAP XSUAA."""
    logger.debug("Fetching new AI Core OAuth token…")
    resp = await client.post(
        f"{settings.AICORE_AUTH_URL}/oauth/token",
        data={
            "grant_type": "client_credentials",
            "client_id": settings.AICORE_CLIENT_ID,
            "client_secret": settings.AICORE_CLIENT_SECRET,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=15,
    )
    resp.raise_for_status()
    payload = resp.json()
    _token_cache.set(payload["access_token"], int(payload.get("expires_in", 3600)))
    logger.info("AI Core token refreshed, expires in %ss", payload.get("expires_in"))
    return _token_cache.token  # type: ignore[return-value]


async def get_bearer_token() -> str:
    """Return a valid bearer token, refreshing if necessary."""
    if _token_cache.is_valid():
        return _token_cache.token  # type: ignore[return-value]
    async with httpx.AsyncClient() as client:
        return await _fetch_token(client)


async def chat_completion(
    messages: list[dict[str, str]],
    *,
    temperature: float = 0.2,
    max_tokens: int = 4096,
) -> dict[str, Any]:
    """
    Call SAP AI Core Generative AI Hub chat/completions endpoint.

    Returns the full API response dict.
    Raises httpx.HTTPStatusError on non-2xx responses.
    """
    token = await get_bearer_token()

    url = (
        f"{settings.AICORE_BASE_URL}/v2/inference/deployments"
        f"/{settings.AICORE_DEPLOYMENT_ID}/chat/completions"
    )

    headers = {
        "Authorization": f"Bearer {token}",
        "AI-Resource-Group": settings.AICORE_RESOURCE_GROUP,
        "Content-Type": "application/json",
    }

    body = {
        "model": settings.AICORE_MODEL,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    logger.debug("POST %s  model=%s  msgs=%d", url, settings.AICORE_MODEL, len(messages))

    async with httpx.AsyncClient(timeout=120) as client:
        resp = await client.post(url, json=body, headers=headers)

    if resp.status_code == 401:
        # Token may have been invalidated server-side; force refresh once
        logger.warning("401 received – forcing token refresh")
        _token_cache._expires_at = 0.0
        token = await get_bearer_token()
        headers["Authorization"] = f"Bearer {token}"
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(url, json=body, headers=headers)

    resp.raise_for_status()
    return resp.json()


def extract_text(response: dict[str, Any]) -> tuple[str, int]:
    """
    Pull assistant message content and total token usage from a chat response.
    Returns (content_text, total_tokens).
    """
    content = response["choices"][0]["message"]["content"]
    tokens = response.get("usage", {}).get("total_tokens", 0)
    return content, tokens
