"""
RAP-ABAP Assistant Service
Builds prompts, calls AI Core, and parses structured responses.
"""

import re
import json
import logging
from typing import Any

from services.aicore_client import chat_completion, extract_text
from models.schemas import (
    GenerateRAPRequest, GenerateRAPResponse,
    ReviewCodeRequest, ReviewCodeResponse, CodeIssue,
    ConvertToRAPRequest, ConvertToRAPResponse,
    ExplainCodeRequest, ExplainCodeResponse,
)
from prompts.rap_prompts import (
    SYSTEM_BASE,
    GENERATE_PROMPT, REVIEW_PROMPT,
    CONVERT_PROMPT, EXPLAIN_PROMPT,
)

logger = logging.getLogger(__name__)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _extract_code_block(text: str, lang: str = "abap") -> str:
    """Pull the first fenced code block from model output."""
    pattern = rf"```(?:{lang})?\s*\n(.*?)```"
    match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
    return match.group(1).strip() if match else text.strip()


def _extract_section(text: str, heading: str) -> str:
    """Extract text under a markdown ### heading."""
    pattern = rf"###\s*{re.escape(heading)}\s*\n(.*?)(?=###|\Z)"
    match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
    return match.group(1).strip() if match else ""


def _extract_bullets(text: str) -> list[str]:
    """Turn markdown bullet list into a Python list of strings."""
    lines = text.splitlines()
    return [
        re.sub(r"^[-*•]\s*", "", ln).strip()
        for ln in lines
        if re.match(r"^[-*•]\s+", ln)
    ]


# ── Generate ──────────────────────────────────────────────────────────────────

async def generate_rap(req: GenerateRAPRequest) -> GenerateRAPResponse:
    prompt = GENERATE_PROMPT.format(
        system=SYSTEM_BASE,
        description=req.description,
        artifact_type=req.artifact_type.value,
        namespace=req.namespace or "Z",
        impl_type=req.managed_or_unmanaged,
        draft_enabled=req.draft_enabled,
        context=req.additional_context or "None",
    )

    messages = [{"role": "user", "content": prompt}]
    response = await chat_completion(messages, temperature=0.1, max_tokens=6000)
    text, tokens = extract_text(response)

    code = _extract_code_block(text, "abap")
    compliance_section = _extract_section(text, "CLEAN CORE COMPLIANCE")
    notes_section = _extract_section(text, "NOTES")

    clean_core_compliant = compliance_section.upper().startswith("YES")
    notes = _extract_bullets(notes_section) or [compliance_section]

    return GenerateRAPResponse(
        artifact_type=req.artifact_type.value,
        description=req.description,
        generated_code=code,
        clean_core_compliant=clean_core_compliant,
        notes=notes,
        tokens_used=tokens,
    )


# ── Review ────────────────────────────────────────────────────────────────────

async def review_code(req: ReviewCodeRequest) -> ReviewCodeResponse:
    prompt = REVIEW_PROMPT.format(
        system=SYSTEM_BASE,
        dialect=req.dialect.value,
        focus_areas=", ".join(req.focus_areas),
        code=req.code,
    )

    messages = [{"role": "user", "content": prompt}]
    response = await chat_completion(messages, temperature=0.0, max_tokens=3000)
    text, tokens = extract_text(response)

    # Model returns raw JSON per prompt instructions
    parsed: dict[str, Any] = {}
    try:
        # Strip accidental markdown fences
        clean = re.sub(r"```(?:json)?", "", text).strip().strip("`")
        parsed = json.loads(clean)
    except json.JSONDecodeError:
        logger.warning("JSON parse failed for review response; returning raw summary")
        parsed = {
            "dialect_detected": req.dialect.value,
            "clean_core_score": 0,
            "issues": [],
            "summary": text,
            "refactored_snippet": None,
        }

    issues = [
        CodeIssue(
            severity=i.get("severity", "info"),
            line_hint=i.get("line_hint"),
            issue=i.get("issue", ""),
            recommendation=i.get("recommendation", ""),
        )
        for i in parsed.get("issues", [])
    ]

    return ReviewCodeResponse(
        dialect_detected=parsed.get("dialect_detected", req.dialect.value),
        clean_core_score=int(parsed.get("clean_core_score", 0)),
        issues=issues,
        summary=parsed.get("summary", ""),
        refactored_snippet=parsed.get("refactored_snippet"),
        tokens_used=tokens,
    )


# ── Convert ───────────────────────────────────────────────────────────────────

async def convert_to_rap(req: ConvertToRAPRequest) -> ConvertToRAPResponse:
    prompt = CONVERT_PROMPT.format(
        system=SYSTEM_BASE,
        target_dialect=req.target_dialect.value,
        preserve_logic=req.preserve_logic,
        code=req.classic_abap,
    )

    messages = [{"role": "user", "content": prompt}]
    response = await chat_completion(messages, temperature=0.1, max_tokens=6000)
    text, tokens = extract_text(response)

    converted = _extract_code_block(text, "abap")
    migration_notes = _extract_bullets(_extract_section(text, "MIGRATION NOTES"))
    breaking_changes = _extract_bullets(_extract_section(text, "BREAKING CHANGES"))

    return ConvertToRAPResponse(
        original_dialect="classic_abap",
        target_dialect=req.target_dialect.value,
        converted_code=converted,
        migration_notes=migration_notes,
        breaking_changes=breaking_changes,
        tokens_used=tokens,
    )


# ── Explain ───────────────────────────────────────────────────────────────────

async def explain_code(req: ExplainCodeRequest) -> ExplainCodeResponse:
    prompt = EXPLAIN_PROMPT.format(
        system=SYSTEM_BASE,
        level=req.level,
        code=req.code,
    )

    messages = [{"role": "user", "content": prompt}]
    response = await chat_completion(messages, temperature=0.3, max_tokens=3000)
    text, tokens = extract_text(response)

    summary = _extract_section(text, "SUMMARY")
    detailed = _extract_section(text, "DETAILED EXPLANATION")
    concepts = _extract_bullets(_extract_section(text, "KEY CONCEPTS"))
    docs = _extract_bullets(_extract_section(text, "RELATED DOCUMENTATION"))

    return ExplainCodeResponse(
        summary=summary or text[:400],
        detailed_explanation=detailed or text,
        key_concepts=concepts,
        related_documentation=docs,
        tokens_used=tokens,
    )
