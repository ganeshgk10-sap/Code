from pydantic import BaseModel, Field
from typing import Optional, Literal
from enum import Enum


class RAPArtifactType(str, Enum):
    CDS_VIEW = "cds_view"
    BEHAVIOR_DEFINITION = "behavior_definition"
    BEHAVIOR_IMPLEMENTATION = "behavior_implementation"
    SERVICE_DEFINITION = "service_definition"
    SERVICE_BINDING = "service_binding"
    FULL_RAP_STACK = "full_rap_stack"


class ABAPDialect(str, Enum):
    CLASSIC = "classic_abap"
    RAP = "rap_abap"
    CLOUD = "abap_cloud"


# ── Generate ─────────────────────────────────────────────────────────────────

class GenerateRAPRequest(BaseModel):
    description: str = Field(
        ...,
        description="Business requirement or entity description to generate RAP artefact for",
        examples=["Purchase Order header and item management with approval workflow"]
    )
    artifact_type: RAPArtifactType = Field(
        default=RAPArtifactType.FULL_RAP_STACK,
        description="Which RAP layer(s) to generate"
    )
    namespace: Optional[str] = Field(
        default="Z",
        description="ABAP namespace prefix (e.g. Z, Y, ZXXX)"
    )
    managed_or_unmanaged: Literal["managed", "unmanaged"] = Field(
        default="managed",
        description="RAP BO implementation type"
    )
    draft_enabled: bool = Field(
        default=False,
        description="Include draft handling in generated artefacts"
    )
    additional_context: Optional[str] = Field(
        default=None,
        description="Any extra constraints, table names, or domain context"
    )


class GenerateRAPResponse(BaseModel):
    artifact_type: str
    description: str
    generated_code: str
    clean_core_compliant: bool
    notes: list[str]
    tokens_used: int


# ── Review ────────────────────────────────────────────────────────────────────

class ReviewCodeRequest(BaseModel):
    code: str = Field(..., description="ABAP or CDS source code to review")
    dialect: ABAPDialect = Field(
        default=ABAPDialect.RAP,
        description="ABAP dialect of the submitted code"
    )
    focus_areas: list[str] = Field(
        default=["clean_core", "performance", "security", "best_practices"],
        description="Review focus areas"
    )


class CodeIssue(BaseModel):
    severity: Literal["critical", "warning", "info"]
    line_hint: Optional[str]
    issue: str
    recommendation: str


class ReviewCodeResponse(BaseModel):
    dialect_detected: str
    clean_core_score: int = Field(..., ge=0, le=100)
    issues: list[CodeIssue]
    summary: str
    refactored_snippet: Optional[str]
    tokens_used: int


# ── Convert ───────────────────────────────────────────────────────────────────

class ConvertToRAPRequest(BaseModel):
    classic_abap: str = Field(
        ...,
        description="Classic ABAP / BOPF code to convert to RAP/Clean Core"
    )
    target_dialect: ABAPDialect = Field(
        default=ABAPDialect.CLOUD,
        description="Target ABAP dialect after conversion"
    )
    preserve_logic: bool = Field(
        default=True,
        description="Preserve business logic; only restructure to RAP patterns"
    )


class ConvertToRAPResponse(BaseModel):
    original_dialect: str
    target_dialect: str
    converted_code: str
    migration_notes: list[str]
    breaking_changes: list[str]
    tokens_used: int


# ── Explain ───────────────────────────────────────────────────────────────────

class ExplainCodeRequest(BaseModel):
    code: str = Field(..., description="ABAP / CDS code to explain")
    level: Literal["beginner", "intermediate", "expert"] = Field(
        default="intermediate",
        description="Explanation depth"
    )


class ExplainCodeResponse(BaseModel):
    summary: str
    detailed_explanation: str
    key_concepts: list[str]
    related_documentation: list[str]
    tokens_used: int


# ── Health ─────────────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status: str
    aicore_reachable: bool
    deployment_id: str
    model: str
