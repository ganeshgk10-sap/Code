from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    # ── SAP BTP AI Core – Service Key fields ─────────────────────────────────
    AICORE_AUTH_URL: str           # e.g. https://<subaccount>.authentication.eu10.hana.ondemand.com
    AICORE_CLIENT_ID: str
    AICORE_CLIENT_SECRET: str
    AICORE_BASE_URL: str           # e.g. https://api.ai.internalprod.eu-central-1.aws.ml.hana.ondemand.com
    AICORE_DEPLOYMENT_ID: str      # Your running deployment of the LLM
    AICORE_RESOURCE_GROUP: str = "default"

    # ── Model selection ───────────────────────────────────────────────────────
    # Common SAP Generative AI Hub model names:
    #   gpt-4o, gpt-4-32k, gpt-35-turbo, amazon--titan-text-express, etc.
    AICORE_MODEL: str = "gpt-4o"

    # ── API settings ──────────────────────────────────────────────────────────
    APP_TITLE: str = "RAP-ABAP Assistant"
    APP_VERSION: str = "1.0.0"
    LOG_LEVEL: str = "INFO"

    # ── Rate limiting (requests per minute per client IP) ─────────────────────
    RATE_LIMIT_RPM: int = 20


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]


settings = get_settings()
