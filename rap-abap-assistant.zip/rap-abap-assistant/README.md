# RAP-ABAP Assistant — FastAPI + SAP BTP AI Core

AI-powered REST API for Clean Core / RAP-ABAP development,
backed by SAP BTP AI Core Generative AI Hub.

---

## Architecture

```
Client
  │
  ▼
FastAPI (main.py)
  ├── POST /api/v1/generate   → rap_assistant.generate_rap()
  ├── POST /api/v1/review     → rap_assistant.review_code()
  ├── POST /api/v1/convert    → rap_assistant.convert_to_rap()
  └── POST /api/v1/explain    → rap_assistant.explain_code()
         │
         ▼
  services/aicore_client.py
    ├── OAuth2 token (XSUAA client_credentials, cached)
    └── POST /v2/inference/deployments/{id}/chat/completions
         │
         ▼
  SAP BTP AI Core – Generative AI Hub (GPT-4o / etc.)
```

---

## Prerequisites

- Python 3.11+
- SAP BTP AI Core instance with a running LLM deployment
- AI Core Service Key (download from BTP Cockpit)

---

## Setup

```bash
# 1. Clone / unzip
cd rap-abap-assistant

# 2. Create virtual environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env — fill in your AI Core service key values
```

---

## Configuration (`.env`)

| Variable | Where to find it |
|---|---|
| `AICORE_AUTH_URL` | Service Key → `uaa.url` |
| `AICORE_CLIENT_ID` | Service Key → `uaa.clientid` |
| `AICORE_CLIENT_SECRET` | Service Key → `uaa.clientsecret` |
| `AICORE_BASE_URL` | Service Key → `serviceurls.AI_API_URL` |
| `AICORE_DEPLOYMENT_ID` | AI Launchpad → ML Operations → Deployments |
| `AICORE_RESOURCE_GROUP` | Usually `default` |
| `AICORE_MODEL` | Model alias in your deployment (e.g. `gpt-4o`) |

---

## Run

```bash
uvicorn main:app --reload --port 8000
```

Interactive docs: http://localhost:8000/docs

---

## API Examples

### Generate a full RAP stack
```bash
curl -X POST http://localhost:8000/api/v1/generate \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Purchase Order header and item with supplier and currency",
    "artifact_type": "full_rap_stack",
    "namespace": "Z",
    "managed_or_unmanaged": "managed",
    "draft_enabled": true
  }'
```

### Review code for Clean Core compliance
```bash
curl -X POST http://localhost:8000/api/v1/review \
  -H "Content-Type: application/json" \
  -d '{
    "code": "SELECT * FROM mara INTO TABLE @DATA(lt_mara).",
    "dialect": "classic_abap",
    "focus_areas": ["clean_core", "performance"]
  }'
```

### Convert Classic ABAP to ABAP Cloud
```bash
curl -X POST http://localhost:8000/api/v1/convert \
  -H "Content-Type: application/json" \
  -d '{
    "classic_abap": "<your classic ABAP here>",
    "target_dialect": "abap_cloud",
    "preserve_logic": true
  }'
```

### Explain code
```bash
curl -X POST http://localhost:8000/api/v1/explain \
  -H "Content-Type: application/json" \
  -d '{
    "code": "<CDS or ABAP snippet>",
    "level": "intermediate"
  }'
```

---

## Run Tests

```bash
pip install pytest pytest-asyncio anyio
pytest tests/ -v
```

> Tests call the live AI Core endpoint — ensure `.env` is configured.

---

## Deployment on BTP (Cloud Foundry)

```bash
# manifest.yml — adjust memory to your needs
cf push rap-abap-assistant \
  --buildpack python_buildpack \
  -m 512M \
  -k 1G \
  --no-route

cf map-route rap-abap-assistant <your-cf-domain> --hostname rap-abap-assistant
```

Set env vars via `cf set-env` or bind the AI Core service instance directly.

---

## Project Structure

```
rap-abap-assistant/
├── main.py                  # FastAPI app & routes
├── config.py                # pydantic-settings config
├── requirements.txt
├── .env.example
├── models/
│   └── schemas.py           # Pydantic request/response models
├── services/
│   ├── aicore_client.py     # OAuth2 + AI Core HTTP client
│   └── rap_assistant.py     # Prompt orchestration & response parsing
├── prompts/
│   └── rap_prompts.py       # System & task prompts
└── tests/
    └── test_api.py          # Integration tests
```
