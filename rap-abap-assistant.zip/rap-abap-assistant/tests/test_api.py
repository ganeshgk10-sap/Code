"""
Integration tests — run against a live AI Core deployment.
Requires a valid .env file.

Usage:
    pip install pytest pytest-asyncio
    pytest tests/test_api.py -v
"""

import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from main import app


@pytest.fixture(scope="session")
def anyio_backend():
    return "asyncio"


@pytest_asyncio.fixture
async def client():
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as c:
        yield c


# ── Health ────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_health(client):
    resp = await client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert "status" in data
    assert "aicore_reachable" in data


# ── Generate ──────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_generate_cds_view(client):
    payload = {
        "description": "Sales Order header entity with customer and currency",
        "artifact_type": "cds_view",
        "namespace": "Z",
        "managed_or_unmanaged": "managed",
        "draft_enabled": False,
    }
    resp = await client.post("/api/v1/generate", json=payload)
    assert resp.status_code == 200
    data = resp.json()
    assert "generated_code" in data
    assert len(data["generated_code"]) > 50
    assert isinstance(data["clean_core_compliant"], bool)
    assert isinstance(data["notes"], list)


@pytest.mark.asyncio
async def test_generate_full_rap_stack(client):
    payload = {
        "description": "Travel expense report with approval",
        "artifact_type": "full_rap_stack",
        "managed_or_unmanaged": "managed",
        "draft_enabled": True,
    }
    resp = await client.post("/api/v1/generate", json=payload)
    assert resp.status_code == 200


# ── Review ────────────────────────────────────────────────────────────────────

SAMPLE_ABAP = """
CLASS zcl_old_report DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS run.
ENDCLASS.
CLASS zcl_old_report IMPLEMENTATION.
  METHOD run.
    SELECT * FROM mara INTO TABLE @DATA(lt_mara).
    LOOP AT lt_mara ASSIGNING FIELD-SYMBOL(<ls>).
      WRITE: / <ls>-matnr.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
"""


@pytest.mark.asyncio
async def test_review_classic_abap(client):
    resp = await client.post("/api/v1/review", json={
        "code": SAMPLE_ABAP,
        "dialect": "classic_abap",
        "focus_areas": ["clean_core", "performance"],
    })
    assert resp.status_code == 200
    data = resp.json()
    assert 0 <= data["clean_core_score"] <= 100
    assert isinstance(data["issues"], list)


# ── Convert ───────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_convert_to_rap(client):
    resp = await client.post("/api/v1/convert", json={
        "classic_abap": SAMPLE_ABAP,
        "target_dialect": "abap_cloud",
        "preserve_logic": True,
    })
    assert resp.status_code == 200
    data = resp.json()
    assert "converted_code" in data
    assert isinstance(data["migration_notes"], list)


# ── Explain ───────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_explain_code(client):
    resp = await client.post("/api/v1/explain", json={
        "code": SAMPLE_ABAP,
        "level": "intermediate",
    })
    assert resp.status_code == 200
    data = resp.json()
    assert len(data["summary"]) > 10
