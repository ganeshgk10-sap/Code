"""
RAP-ABAP Assistant  —  FastAPI REST API
Powered by SAP BTP AI Core / Generative AI Hub

Endpoints:
  GET  /health                   → liveness + AI Core reachability
  POST /api/v1/generate          → Generate RAP artefact(s) from description
  POST /api/v1/review            → Clean Core code review
  POST /api/v1/convert           → Classic ABAP → RAP/Cloud conversion
  POST /api/v1/explain           → Plain-language code explanation
"""

import logging
import httpx

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from config import settings
from models.schemas import (
    GenerateRAPRequest, GenerateRAPResponse,
    ReviewCodeRequest, ReviewCodeResponse,
    ConvertToRAPRequest, ConvertToRAPResponse,
    ExplainCodeRequest, ExplainCodeResponse,
    HealthResponse,
)
from services import rap_assistant
from services.aicore_client import get_bearer_token

# ── Logging ───────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=settings.LOG_LEVEL,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(
    title=settings.APP_TITLE,
    version=settings.APP_VERSION,
    description=(
        "Clean Core / RAP-ABAP AI assistant powered by SAP BTP AI Core. "
        "Generate, review, convert, and explain ABAP & CDS code using LLMs "
        "running inside your SAP landscape."
    ),
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # Tighten in production
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


# ── Global error handler ──────────────────────────────────────────────────────

@app.exception_handler(httpx.HTTPStatusError)
async def aicore_http_error_handler(request: Request, exc: httpx.HTTPStatusError):
    status_code = exc.response.status_code
    detail = f"SAP AI Core returned HTTP {status_code}: {exc.response.text[:300]}"
    logger.error(detail)
    return JSONResponse(
        status_code=status.HTTP_502_BAD_GATEWAY,
        content={"detail": detail},
    )


@app.exception_handler(httpx.TimeoutException)
async def aicore_timeout_handler(request: Request, exc: httpx.TimeoutException):
    logger.error("SAP AI Core request timed out")
    return JSONResponse(
        status_code=status.HTTP_504_GATEWAY_TIMEOUT,
        content={"detail": "SAP AI Core request timed out. Try a shorter input."},
    )


# ── Health ─────────────────────────────────────────────────────────────────────

@app.get(
    "/health",
    response_model=HealthResponse,
    tags=["Operations"],
    summary="Liveness and AI Core connectivity check",
)
async def health_check() -> HealthResponse:
    reachable = False
    try:
        await get_bearer_token()
        reachable = True
    except Exception as exc:
        logger.warning("AI Core health check failed: %s", exc)

    return HealthResponse(
        status="ok" if reachable else "degraded",
        aicore_reachable=reachable,
        deployment_id=settings.AICORE_DEPLOYMENT_ID,
        model=settings.AICORE_MODEL,
    )


# ── Generate ──────────────────────────────────────────────────────────────────

@app.post(
    "/api/v1/generate",
    response_model=GenerateRAPResponse,
    tags=["RAP Assistant"],
    summary="Generate RAP artefact(s) from a business description",
    status_code=status.HTTP_200_OK,
)
async def generate_rap(request: GenerateRAPRequest) -> GenerateRAPResponse:
    """
    Accepts a natural-language business requirement and returns one or more
    RAP artefacts (CDS views, Behaviour Definitions, Implementations,
    Service Definitions/Bindings) that are Clean Core compliant.
    """
    logger.info(
        "generate | artifact=%s | impl=%s | draft=%s",
        request.artifact_type, request.managed_or_unmanaged, request.draft_enabled
    )
    return await rap_assistant.generate_rap(request)


# ── Review ────────────────────────────────────────────────────────────────────

@app.post(
    "/api/v1/review",
    response_model=ReviewCodeResponse,
    tags=["RAP Assistant"],
    summary="Clean Core review of submitted ABAP / CDS code",
)
async def review_code(request: ReviewCodeRequest) -> ReviewCodeResponse:
    """
    Analyses ABAP or CDS source for Clean Core compliance, performance
    antipatterns, security issues, and best-practice violations.
    Returns a score (0–100) and itemised findings.
    """
    logger.info("review | dialect=%s | focus=%s", request.dialect, request.focus_areas)
    return await rap_assistant.review_code(request)


# ── Convert ───────────────────────────────────────────────────────────────────

@app.post(
    "/api/v1/convert",
    response_model=ConvertToRAPResponse,
    tags=["RAP Assistant"],
    summary="Convert Classic ABAP / BOPF to RAP / ABAP Cloud",
)
async def convert_to_rap(request: ConvertToRAPRequest) -> ConvertToRAPResponse:
    """
    Takes Classic ABAP (including BOPF, function modules, or reports) and
    migrates it to the target dialect — ABAP for Cloud Development or RAP.
    Returns the converted code plus migration and breaking-change notes.
    """
    logger.info("convert | target=%s | preserve_logic=%s", request.target_dialect, request.preserve_logic)
    return await rap_assistant.convert_to_rap(request)


# ── Explain ───────────────────────────────────────────────────────────────────

@app.post(
    "/api/v1/explain",
    response_model=ExplainCodeResponse,
    tags=["RAP Assistant"],
    summary="Plain-language explanation of ABAP / CDS code",
)
async def explain_code(request: ExplainCodeRequest) -> ExplainCodeResponse:
    """
    Explains what a piece of ABAP or CDS code does — at beginner,
    intermediate, or expert level — and surfaces related SAP documentation.
    """
    logger.info("explain | level=%s", request.level)
    return await rap_assistant.explain_code(request)
